
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <i className="fas fa-terminal text-white text-xl"></i>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
            Code-Expert
          </h1>
        </div>
        <nav className="hidden md:flex gap-6">
          <a href="#" className="text-sm font-medium text-indigo-400 border-b-2 border-indigo-400 pb-1">Analyseur</a>
          <a href="#" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Documentation</a>
          <a href="#" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">À propos</a>
        </nav>
        <div className="flex items-center gap-4">
          <button className="text-slate-400 hover:text-white">
            <i className="fab fa-github text-xl"></i>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
