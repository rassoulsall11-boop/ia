
export type ProgrammingLanguage = 
  | 'python' 
  | 'html' 
  | 'css' 
  | 'javascript' 
  | 'typescript' 
  | 'cpp' 
  | 'java' 
  | 'go' 
  | 'rust';

export interface CodeError {
  description: string;
  fix: string;
  reason: string;
}

export interface CodeOptimization {
  description: string;
  benefit: string;
  explanation: string;
}

export interface AnalysisResult {
  status: 'success' | 'warning' | 'error';
  summary: string;
  errors: CodeError[];
  optimizations: CodeOptimization[];
  improvedCode: string;
}

export interface AnalysisState {
  isLoading: boolean;
  result: AnalysisResult | null;
  error: string | null;
}

export interface HistoryItem {
  id: string;
  timestamp: number;
  language: ProgrammingLanguage;
  originalCode: string;
  result: AnalysisResult;
}
