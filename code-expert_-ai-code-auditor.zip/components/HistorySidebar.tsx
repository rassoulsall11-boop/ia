
import React from 'react';
import { HistoryItem, ProgrammingLanguage } from '../types';

interface HistorySidebarProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryItem[];
  onSelectItem: (item: HistoryItem) => void;
  onClearHistory: () => void;
}

const langIcons: Record<string, string> = {
  python: 'fab fa-python text-blue-400',
  javascript: 'fab fa-js text-yellow-400',
  typescript: 'fas fa-code text-blue-500',
  html: 'fab fa-html5 text-orange-500',
  css: 'fab fa-css3-alt text-indigo-400',
  cpp: 'fas fa-microchip text-slate-400',
  java: 'fab fa-java text-red-400',
  rust: 'fas fa-gear text-orange-600',
  go: 'fas fa-bolt text-cyan-400',
};

const HistorySidebar: React.FC<HistorySidebarProps> = ({
  isOpen,
  onClose,
  history,
  onSelectItem,
  onClearHistory
}) => {
  const formatTime = (ts: number) => {
    return new Intl.DateTimeFormat('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: 'short'
    }).format(ts);
  };

  return (
    <>
      {/* Overlay */}
      <div 
        className={`fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-[60] transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <aside 
        className={`fixed right-0 top-0 h-full w-full max-w-sm bg-slate-900 border-l border-slate-800 z-[70] shadow-2xl transform transition-transform duration-300 ease-out flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div>
            <h3 className="text-xl font-bold text-white">Historique</h3>
            <p className="text-xs text-slate-500 mt-1">{history.length} audit(s) enregistré(s)</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-4 space-y-3 no-scrollbar">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <i className="fas fa-history text-4xl text-slate-700 mb-4"></i>
              <p className="text-slate-500 text-sm">Aucun historique disponible.</p>
            </div>
          ) : (
            history.map((item) => (
              <button
                key={item.id}
                onClick={() => onSelectItem(item)}
                className="w-full text-left p-4 rounded-xl bg-slate-800/40 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800 transition-all group"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <i className={`${langIcons[item.language] || 'fas fa-code'} text-sm`}></i>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.language}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{formatTime(item.timestamp)}</span>
                </div>
                <p className="text-sm text-slate-300 font-medium line-clamp-2 group-hover:text-white transition-colors">
                  {item.result.summary}
                </p>
                <div className="mt-3 flex gap-2">
                  {item.result.errors.length > 0 && (
                    <span className="text-[9px] px-2 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
                      {item.result.errors.length} erreurs
                    </span>
                  )}
                  {item.result.optimizations.length > 0 && (
                    <span className="text-[9px] px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                      {item.result.optimizations.length} opts
                    </span>
                  )}
                </div>
              </button>
            ))
          )}
        </div>

        {history.length > 0 && (
          <div className="p-4 border-t border-slate-800 bg-slate-900/80">
            <button
              onClick={onClearHistory}
              className="w-full py-2.5 rounded-lg border border-rose-500/30 text-rose-400 hover:bg-rose-500 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-2"
            >
              <i className="fas fa-trash-alt text-[10px]"></i>
              Effacer l'historique
            </button>
          </div>
        )}
      </aside>
    </>
  );
};

export default HistorySidebar;
