
import React, { useState } from 'react';
import { AnalysisResult as AnalysisResultType } from '../types';

interface AnalysisResultProps {
  result: AnalysisResultType;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result }) => {
  const [activeTab, setActiveTab] = useState<'feedback' | 'code'>('feedback');
  const [copied, setCopied] = useState(false);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(result.improvedCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Clipboard API failed, trying fallback:', err);
      // Fallback method using a temporary textarea
      const textArea = document.createElement("textarea");
      textArea.value = result.improvedCode;
      
      // Ensure the textarea is not visible but part of the DOM
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      textArea.style.top = "0";
      document.body.appendChild(textArea);
      
      textArea.focus();
      textArea.select();
      
      try {
        const successful = document.execCommand('copy');
        if (successful) {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }
      } catch (fallbackErr) {
        console.error('Fallback copy failed:', fallbackErr);
      }
      
      document.body.removeChild(textArea);
    }
  };

  const getStatusIcon = () => {
    switch (result.status) {
      case 'success': return <i className="fas fa-check-circle text-emerald-400"></i>;
      case 'warning': return <i className="fas fa-exclamation-triangle text-amber-400"></i>;
      case 'error': return <i className="fas fa-times-circle text-rose-400"></i>;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-2xl transition-all animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Tabs */}
      <div className="flex items-center justify-between px-4 bg-slate-800/50 border-b border-slate-800">
        <div className="flex">
          <button
            onClick={() => setActiveTab('feedback')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'feedback' 
                ? 'border-indigo-500 text-indigo-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Analyse
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'code' 
                ? 'border-indigo-500 text-indigo-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Code Optimisé
          </button>
        </div>
        
        {activeTab === 'code' && (
          <button
            onClick={copyToClipboard}
            className="flex items-center gap-2 px-3 py-1 bg-slate-700 hover:bg-slate-600 rounded text-xs font-medium text-slate-200 transition-colors"
          >
            {copied ? <i className="fas fa-check"></i> : <i className="far fa-copy"></i>}
            {copied ? 'Copié !' : 'Copier'}
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-grow overflow-y-auto no-scrollbar p-6 bg-slate-900">
        {activeTab === 'feedback' ? (
          <div className="space-y-8">
            <section>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-2xl">{getStatusIcon()}</span>
                <h3 className="text-lg font-bold text-white capitalize">{result.status}</h3>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">
                {result.summary}
              </p>
            </section>

            {result.errors.length > 0 && (
              <section className="space-y-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                  Erreurs Détectées ({result.errors.length})
                </h4>
                {result.errors.map((error, idx) => (
                  <div key={idx} className="bg-rose-500/5 border border-rose-500/20 rounded-lg p-4 space-y-2">
                    <p className="text-sm text-rose-200 font-medium">{error.description}</p>
                    <div className="bg-slate-950/50 rounded p-2 text-xs font-mono text-emerald-400">
                      Fix: {error.fix}
                    </div>
                    <p className="text-xs text-slate-500 italic">
                      <span className="font-semibold text-slate-400">Pourquoi :</span> {error.reason}
                    </p>
                  </div>
                ))}
              </section>
            )}

            {result.optimizations.length > 0 && (
              <section className="space-y-4">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                  Optimisations ({result.optimizations.length})
                </h4>
                {result.optimizations.map((opt, idx) => (
                  <div key={idx} className="bg-indigo-500/5 border border-indigo-500/20 rounded-lg p-4 space-y-2">
                    <p className="text-sm text-indigo-200 font-medium">{opt.description}</p>
                    <div className="text-xs text-emerald-400/80">
                      <i className="fas fa-rocket mr-2"></i> Bénéfice : {opt.benefit}
                    </div>
                    <p className="text-xs text-slate-500 italic">
                      <span className="font-semibold text-slate-400">Pourquoi :</span> {opt.explanation}
                    </p>
                  </div>
                ))}
              </section>
            )}
            
            {result.errors.length === 0 && result.optimizations.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-slate-500">
                <i className="fas fa-medal text-4xl mb-4 text-emerald-500/20"></i>
                <p>Excellent travail ! Aucun problème détecté.</p>
              </div>
            )}
          </div>
        ) : (
          <div className="relative">
            <pre className="font-mono text-sm text-slate-300 whitespace-pre-wrap break-all leading-relaxed">
              <code>{result.improvedCode}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisResult;
