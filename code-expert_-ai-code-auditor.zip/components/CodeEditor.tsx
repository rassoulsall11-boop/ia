
import React from 'react';
import { ProgrammingLanguage } from '../types';

interface CodeEditorProps {
  code: string;
  setCode: (code: string) => void;
  language: ProgrammingLanguage;
  setLanguage: (lang: ProgrammingLanguage) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

const languages: { id: ProgrammingLanguage; label: string; icon: string }[] = [
  { id: 'python', label: 'Python', icon: 'fab fa-python' },
  { id: 'javascript', label: 'JS', icon: 'fab fa-js' },
  { id: 'typescript', label: 'TS', icon: 'fas fa-code' },
  { id: 'html', label: 'HTML', icon: 'fab fa-html5' },
  { id: 'css', label: 'CSS', icon: 'fab fa-css3-alt' },
  { id: 'cpp', label: 'C++', icon: 'fas fa-microchip' },
  { id: 'java', label: 'Java', icon: 'fab fa-java' },
  { id: 'rust', label: 'Rust', icon: 'fas fa-gear' },
  { id: 'go', label: 'Go', icon: 'fas fa-bolt' },
];

const CodeEditor: React.FC<CodeEditorProps> = ({
  code,
  setCode,
  language,
  setLanguage,
  onAnalyze,
  isAnalyzing
}) => {
  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden shadow-2xl">
      {/* Tool bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between p-2 bg-slate-800/50 border-b border-slate-800 gap-3">
        <div className="flex flex-wrap gap-1">
          {languages.map((lang) => (
            <button
              key={lang.id}
              onClick={() => setLanguage(lang.id)}
              title={lang.label}
              className={`flex items-center gap-2 px-2.5 py-1.5 text-[10px] font-bold rounded transition-all uppercase ${
                language === lang.id 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
              }`}
            >
              <i className={lang.icon}></i>
              <span className="hidden xs:inline">{lang.label}</span>
            </button>
          ))}
        </div>
        <button
          onClick={onAnalyze}
          disabled={isAnalyzing || !code.trim()}
          className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all ${
            isAnalyzing || !code.trim()
              ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
          }`}
        >
          {isAnalyzing ? (
            <>
              <i className="fas fa-circle-notch fa-spin"></i>
              Audit...
            </>
          ) : (
            <>
              <i className="fas fa-shield-check mr-1"></i>
              Lancer l'Audit
            </>
          )}
        </button>
      </div>

      {/* Editor area */}
      <div className="relative flex-grow min-h-[450px]">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder={`Collez votre code ${language} ici pour un audit complet...`}
          className="w-full h-full p-4 bg-slate-900 text-slate-300 font-mono text-sm resize-none focus:outline-none no-scrollbar leading-relaxed"
          spellCheck={false}
        />
        <div className="absolute bottom-4 right-4 text-[10px] text-slate-600 font-mono pointer-events-none bg-slate-900/80 px-2 py-1 rounded">
          {language.toUpperCase()} | {code.length} chars
        </div>
      </div>
    </div>
  );
};

export default CodeEditor;
