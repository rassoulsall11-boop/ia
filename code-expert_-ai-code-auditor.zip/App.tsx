
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import CodeEditor from './components/CodeEditor';
import AnalysisResult from './components/AnalysisResult';
import HistorySidebar from './components/HistorySidebar';
import { ProgrammingLanguage, AnalysisState, HistoryItem } from './types';
import { analyzeCode } from './services/gemini';

const App: React.FC = () => {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState<ProgrammingLanguage>('python');
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [analysis, setAnalysis] = useState<AnalysisState>({
    isLoading: false,
    result: null,
    error: null,
  });

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('code_expert_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    localStorage.setItem('code_expert_history', JSON.stringify(history));
  }, [history]);

  const handleAnalyze = async () => {
    if (!code.trim()) return;

    setAnalysis((prev) => ({ ...prev, isLoading: true, error: null }));
    try {
      const result = await analyzeCode(code, language);
      setAnalysis({ isLoading: false, result, error: null });

      // Add to history
      const newItem: HistoryItem = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        language,
        originalCode: code,
        result
      };
      setHistory(prev => [newItem, ...prev].slice(0, 20)); // Keep last 20
    } catch (err) {
      console.error('Analysis failed:', err);
      setAnalysis({
        isLoading: false,
        result: null,
        error: 'Une erreur est survenue lors de l\'analyse. Veuillez vérifier votre connexion ou réessayer plus tard.',
      });
    }
  };

  const handleSelectHistoryItem = (item: HistoryItem) => {
    setCode(item.originalCode);
    setLanguage(item.language);
    setAnalysis({
      isLoading: false,
      result: item.result,
      error: null
    });
    setIsHistoryOpen(false);
    // Scroll to results
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const clearHistory = () => {
    if (window.confirm("Voulez-vous vraiment effacer tout l'historique ?")) {
      setHistory([]);
      localStorage.removeItem('code_expert_history');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 selection:bg-indigo-500/30">
      <Header />
      
      {/* History Trigger Button */}
      <button 
        onClick={() => setIsHistoryOpen(true)}
        className="fixed bottom-8 right-8 z-40 w-14 h-14 bg-indigo-600 text-white rounded-full shadow-2xl shadow-indigo-600/40 hover:bg-indigo-500 hover:scale-110 active:scale-95 transition-all flex items-center justify-center group"
        title="Ouvrir l'historique"
      >
        <i className="fas fa-history text-xl group-hover:rotate-[-45deg] transition-transform"></i>
        {history.length > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-slate-950">
            {history.length}
          </span>
        )}
      </button>

      <HistorySidebar 
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelectItem={handleSelectHistoryItem}
        onClearHistory={clearHistory}
      />

      <main className="flex-grow max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        <div className="mb-10 text-center max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6 tracking-tight">
            Audit de Code <span className="text-indigo-500">Haute Performance</span>.
          </h2>
          <p className="text-slate-400 text-lg md:text-xl leading-relaxed">
            Spécialiste de l'optimisation CSS et du nettoyage multi-langages. 
            Améliorez votre <span className="text-slate-200 font-semibold underline decoration-indigo-500 decoration-2">Critical Rendering Path</span> et la qualité de votre logique métier.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start min-h-[700px]">
          <div className="flex flex-col h-full">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-sm">01</div>
              <h3 className="font-bold text-slate-200">Source à Auditer</h3>
            </div>
            <CodeEditor
              code={code}
              setCode={setCode}
              language={language}
              setLanguage={setLanguage}
              onAnalyze={handleAnalyze}
              isAnalyzing={analysis.isLoading}
            />
          </div>

          <div className="flex flex-col h-full">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-sm">02</div>
              <h3 className="font-bold text-slate-200">Rapport d'Expertise</h3>
            </div>
            
            {!analysis.isLoading && !analysis.result && !analysis.error && (
              <div className="flex flex-col items-center justify-center h-full min-h-[450px] bg-slate-900/40 rounded-xl border border-dashed border-slate-800 p-8 text-center">
                <div className="w-20 h-20 bg-slate-800/50 rounded-2xl flex items-center justify-center mb-6 border border-slate-700">
                  <i className="fas fa-microscope text-3xl text-slate-500"></i>
                </div>
                <h4 className="text-slate-300 font-bold mb-2">Analyse non initiée</h4>
                <p className="text-slate-500 text-sm max-w-md">
                  Soumettez un script Python, une structure HTML complexe ou des feuilles de style CSS pour obtenir un rapport détaillé.
                </p>
                {history.length > 0 && (
                  <button 
                    onClick={() => setIsHistoryOpen(true)}
                    className="mt-6 text-indigo-400 hover:text-indigo-300 text-xs font-bold underline underline-offset-4"
                  >
                    Voir vos audits récents
                  </button>
                )}
              </div>
            )}

            {analysis.isLoading && (
              <div className="flex flex-col items-center justify-center h-full min-h-[450px] bg-slate-900/40 rounded-xl border border-slate-800 p-8">
                <div className="relative mb-8">
                  <div className="w-20 h-20 border-4 border-indigo-500/10 border-t-indigo-500 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <i className="fas fa-shield-halved text-indigo-500 text-2xl animate-pulse"></i>
                  </div>
                </div>
                <h4 className="text-white font-bold mb-2">Scan en cours...</h4>
                <p className="text-slate-500 text-sm text-center max-w-xs">
                  Vérification de la complexité, des sélecteurs CSS et de la conformité syntaxique.
                </p>
              </div>
            )}

            {analysis.error && (
              <div className="flex flex-col items-center justify-center h-full min-h-[450px] bg-rose-500/5 rounded-xl border border-rose-500/20 p-8 text-center">
                <i className="fas fa-bug text-4xl text-rose-500 mb-6"></i>
                <h4 className="text-rose-200 font-bold mb-2">Erreur d'Audit</h4>
                <p className="text-rose-300/60 text-sm mb-6">{analysis.error}</p>
                <button 
                  onClick={handleAnalyze}
                  className="bg-rose-600 hover:bg-rose-500 text-white font-bold py-2 px-6 rounded-lg transition-all"
                >
                  Retenter l'Analyse
                </button>
              </div>
            )}

            {analysis.result && !analysis.isLoading && (
              <AnalysisResult result={analysis.result} />
            )}
          </div>
        </div>

        {/* Specialized audit cards */}
        <section className="mt-24">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 hover:bg-slate-900 transition-all">
              <i className="fas fa-bolt text-amber-500 mb-4 block text-xl"></i>
              <h4 className="text-white font-bold mb-2">CSS Performance</h4>
              <p className="text-slate-500 text-xs leading-relaxed">Audit des sélecteurs pour réduire le temps de calcul des styles et améliorer le score LCP.</p>
            </div>
            <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 hover:bg-slate-900 transition-all">
              <i className="fab fa-python text-blue-500 mb-4 block text-xl"></i>
              <h4 className="text-white font-bold mb-2">Python Logic</h4>
              <p className="text-slate-500 text-xs leading-relaxed">Détection de complexité cyclomatique élevée et non-respect des PEP 8/20.</p>
            </div>
            <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 hover:bg-slate-900 transition-all">
              <i className="fas fa-shield-virus text-emerald-500 mb-4 block text-xl"></i>
              <h4 className="text-white font-bold mb-2">Security Scan</h4>
              <p className="text-slate-500 text-xs leading-relaxed">Identification des vulnérabilités classiques (XSS, injections, fuites mémoire).</p>
            </div>
            <div className="p-6 bg-slate-900/50 rounded-2xl border border-slate-800 hover:bg-slate-900 transition-all">
              <i className="fas fa-universal-access text-purple-500 mb-4 block text-xl"></i>
              <h4 className="text-white font-bold mb-2">Accessibility</h4>
              <p className="text-slate-500 text-xs leading-relaxed">Audit ARIA et sémantique HTML pour garantir l'inclusion de tous les utilisateurs.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-900 py-10 bg-slate-950 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex justify-center gap-6 mb-4">
            <i className="fab fa-github text-slate-700 hover:text-white cursor-pointer transition-colors"></i>
            <i className="fab fa-twitter text-slate-700 hover:text-white cursor-pointer transition-colors"></i>
            <i className="fab fa-linkedin text-slate-700 hover:text-white cursor-pointer transition-colors"></i>
          </div>
          <p className="text-slate-600 text-xs tracking-widest uppercase">
            Code-Expert Engine v2.5 — Analyseur de Performance
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
