
import { GoogleGenAI, Type } from "@google/genai";
import { ProgrammingLanguage, AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const analyzeCode = async (
  code: string,
  language: ProgrammingLanguage
): Promise<AnalysisResult> => {
  const model = 'gemini-3-flash-preview';
  
  const systemInstruction = `
    Tu es Code-Expert, un ingénieur senior spécialisé dans l'audit de code et la performance logicielle.
    Ton expertise couvre Python, HTML, CSS, JavaScript, TypeScript, C++, Java, Go et Rust.
    
    CONSIGNES SPÉCIFIQUES POUR CSS :
    - Identifie les sélecteurs trop génériques (ex: usage excessif de *).
    - Repère les sélecteurs descendants trop profonds (ex: body div main section ul li a) qui ralentissent le moteur de rendu.
    - Analyse la spécificité pour éviter les conflits et l'usage de !important.
    - Explique l'impact sur le "Recalculate Style" et la vitesse de chargement.

    CONSIGNES GÉNÉRALES :
    - Détecte les erreurs de syntaxe et bugs logiques.
    - Propose des optimisations de performance (complexité algorithmique, gestion mémoire).
    - Fournis systématiquement une explication technique "POURQUOI" pour chaque recommandation.
    - Ton ton doit être expert, pédagogue et direct.
    
    IMPORTANT: 
    - Le JSON de sortie doit être complet et valide.
    - Si le code source est très long, concentre-toi sur les sections critiques dans "improvedCode" mais veille à ce que le résultat reste un code fonctionnel.
    - Évite les explications verbeuses pour ne pas dépasser les limites de sortie et risquer une troncature du JSON.
  `;

  const prompt = `Analyse ce code écrit en ${language} :\n\n${code}`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      systemInstruction: systemInstruction,
      responseMimeType: "application/json",
      maxOutputTokens: 8192, // Increased limit to handle larger code snippets
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: {
            type: Type.STRING,
            description: "Statut (success, warning, error)",
          },
          summary: {
            type: Type.STRING,
            description: "Résumé global de l'audit.",
          },
          errors: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                fix: { type: Type.STRING },
                reason: { type: Type.STRING, description: "Justification technique de la correction." },
              },
              required: ["description", "fix", "reason"],
            },
          },
          optimizations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                benefit: { type: Type.STRING },
                explanation: { type: Type.STRING, description: "Impact sur la performance ou maintenabilité." },
              },
              required: ["description", "benefit", "explanation"],
            },
          },
          improvedCode: {
            type: Type.STRING,
            description: "Code complet corrigé et optimisé.",
          },
        },
        required: ["status", "summary", "errors", "optimizations", "improvedCode"],
      },
    },
  });

  try {
    const text = response.text || "";
    if (!text) {
      throw new Error("L'API n'a pas retourné de texte.");
    }
    return JSON.parse(text.trim()) as AnalysisResult;
  } catch (e) {
    console.error("JSON parse error for response:", response.text, e);
    throw new Error("La réponse de l'audit est trop volumineuse ou malformée. Veuillez essayer d'analyser un bloc de code plus court.");
  }
};
